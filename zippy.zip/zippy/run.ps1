python ./read_md.py
python ./scubaoscal.py